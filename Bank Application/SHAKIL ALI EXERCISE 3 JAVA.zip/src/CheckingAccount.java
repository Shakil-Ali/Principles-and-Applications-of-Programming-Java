
// Public class 'CheckingAccount' extending BankAccount
public class CheckingAccount extends BankAccount {

	// (Instance) Variable initialisation
	public static int numberOfChecksUsed = 0;
	public static int numberOfTransactions = 0;
	// Static counter for every time a checking account is made
	static int numberOfCheckingAccounts = 0;
	
	// CheckingAccount constructor
	public CheckingAccount(String id, double initialBalance)
	{
		// Call to the super class BankAccount
		super(id, initialBalance);
		// Increment this counter every time this constructor is called (a new checking account is made)
		numberOfCheckingAccounts++;
	}
	
	// 	Public withdraw method, with an argument 'amount'
	public boolean withdraw(double amount) 
	{
		// Check if amount is 0 or non-positive
		if(amount <= 0)
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
		// If statement to check if the amount, plus transaction fee will go below 0
		if(this.balance - amount - 1 >= 0)
		{
			// Minus the amount and �1 from the balance
			this.balance = this.balance - (amount + 1);
			// Increment the number of transactions
			numberOfTransactions++;
			// Transaction successful message
			System.out.println("TRANSACTION SUCCESSFUL");
			// Return true statement
			return true;
		}
		// Transaction failed message
		System.out.println("TRANSACTION FAILED");
		// Return false statement
		return false;
	}
	
	// Deposit method, which takes one argument 'amount'
	public void deposit(double amount) 
	{
		// If statement to check if amount deposited is �1 or greater
		if(amount >= 1)
		{
			// Adds the amount to the balance
			this.balance += amount;
			// Subtract �1 transaction fee
			this.balance -= 1;
			// Increment the number of transactions counter by 1
			numberOfTransactions++;
			// Transaction successful message
			System.out.println("TRANSACTION SUCCESSFUL");
		}
	}
	
	// ResetChecksUsed method
	public void resetChecksUsed()
	{
		// Set the number of checks used to zero
		numberOfChecksUsed = 0;
	}
	
	// WithdrawUsingCheckMethod, takes argument 'amount'
	public boolean withdrawUsingCheck(double amount)
	{	
		// Check if amount is less than or equal to 0, if it is, return false
		if(amount <= 0)
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
		// Conditional statement to check if number of checks used is less than 3
		if(numberOfChecksUsed < 3)
		{
			// Conditional if statement to check if balance - amount, is less than -10
			if(this.balance - amount < -10)
			{
				// Transaction failed message
				System.out.println("TRANSACTION FAILED");
				// Return false statement
				return false;
			}
			// Conditional else statement 
			else
			{
				// Subtract the amount from the balance 
				this.balance -= amount;
				// Increment the number of transactions used by 1
				numberOfTransactions++;
				// Increment the number of transactions used by 1
				numberOfChecksUsed++;
				// Transaction successful message
				System.out.println("TRANSACTION SUCCESSFUL");
				// Return true statement
				return true;
			}
		}
		// Conditional else statement
		else
		{
			// Conditional if statement to check if balance minus the amount and transaction fee
			// are less than -10
			if(this.balance - (amount + 2) < -10)
			{
				// Transaction failed message
				System.out.println("TRANSACTION FAILED");
				// Return false statement
				return false;
			}
			// Conditional else statement
			else
			{
				// Subtract the amount, and transaction fee �2, from balance
				this.balance -= (amount + 2);
				// Increment the number of transactions by 1
				numberOfTransactions++;
				// Increment the number of checks used by 1
				numberOfChecksUsed++;
				// Transaction successful message
				System.out.println("TRANSACTION SUCCESSFUL");
				// Return true statement
				return true;
			}
		}
		
	}
	
	
}
