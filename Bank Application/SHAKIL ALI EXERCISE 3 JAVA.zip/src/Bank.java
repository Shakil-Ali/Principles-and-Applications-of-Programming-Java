// Import java util for the array list
import java.util.*;

// Public class Bank
public class Bank {
	
	// String to store name of bank
	String name;
	
	// ArrayList to store the accounts
	ArrayList<BankAccount> accounts = new ArrayList<BankAccount>();
	
	// Double to store interest rate for savings account
	double savingsInterestRate;
	
	// Constructor Bank, with arguments 'name' and 'savingsInterestRate'
	public Bank(String name, double savingsInterestRate)
	{
		// Set the name to argument name
		this.name = name;
		// Set the savingsInterestRate to argument savingsInterestRate
		this.savingsInterestRate = savingsInterestRate;
	}
	
	// Method for returning account matching accountD
	public BankAccount getAccount(String accountID)
	{
		// Integer to store size of accounts array list
		int len = accounts.size();
		// For loop iterating the ArrayList 'accounts'
		for(int i = 0; i < len; i++)
		{
			// Conditional if statement to check if an Id in accounts matches 'accountID'
			if(accounts.get(i).getId() == accountID)
			{
				// Return the account from the accounts ArrayList, which has the matching accountID
				return accounts.get(i);
			}
		}
		// Account not found message
		System.out.println("ACCOUNT NOT FOUND");
		// Return null statement
		return null;
	}
	
	// Method for depositing, has two arguments: 'accountID' and 'amount'
	public boolean deposit(String accountID, double amount)
	{
		// Check if amount being deposited is less than or equal to 0, if it is, return false
		if(amount <= 0)
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
		// Create a new account, with type BankAccount
		// Set it to getAccount with argument 'accountID'
		BankAccount account = getAccount(accountID);
		// If statement to check if there is no account with that ID
		if(account == null)
		{
			// Failed to find account message
			System.out.println("ACCOUNT NOT FOUND");
			// Return false statement
			return false;
		}
		// Conditional else statement
		else
		{
			// If account exists, deposit the 'amount'
			account.deposit(amount);
			// Transaction successful message
			System.out.println("TRANSACTION SUCCESSFUL");
			// Return true statement
			return true;
		}
	}
	
	// Method for withdrawing, with two arguments: 'accountID' and 'amount'
	public boolean withdraw(String accountID, double amount)
	{
		// Check if amount being withdrawn is less than or equal to 0, if it is, return false
		if(amount <= 0)
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
		// New account made with type BankAccount
		// Set to the value getAccount with argument accountID
		BankAccount account = getAccount(accountID);
		// Conditional if statement to check if account exists
		if(account == null)
		{
			// Failed to find account message
			System.out.println("ACCOUNT NOT FOUND");
			// Return false statement
			return false;
		}
		// Conditional else statement
		else
		{
			// Apply withdraw, with the argument amount, to account
			account.withdraw(amount);
			// Transaction successful message
			System.out.println("TRANSACTION SUCCESSFUL");
			// Return true statement
			return true;
		}
	}
	
	// Method for transferring, takes three arguments: fromAccountID, toAccountID and amount
	public boolean transfer(String fromAccountID, String toAccountID, double amount)
	{
		// Check if amount being transferred is less than or equal to 0, if it is, return false
		if(amount <= 0)
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
		// Create BankLosing with type BankAccount, and set it getAccount with argument fromAccountID
		BankAccount BankLosing = getAccount(fromAccountID);
		// Create BankGetting with type BankAccount, and set it getAccount with argument toAccountID
		BankAccount BankGetting = getAccount(toAccountID);
	
		// If statement to check if either of the BankLosing or BankGetting exist
		if(BankLosing == null || BankGetting == null)
		{
			// Failed to find account message
			System.out.println("ACCOUNT NOT FOUND");
			// Return false statement
			return false;
		}
	
		// If statement to check if withdraw, with argument amount, is able to be applied to BankLosing
		if (BankLosing.withdraw(amount))
		{
			// Deposit amount into the BankingGetting id
			deposit(BankGetting.id, amount);
			// Transaction successful message
			System.out.println("TRANSACTION SUCCESSFUL");
			// Return true statement
			return true;
		}
		// Conditional else statement
		else
		{
			// Transaction failed message
			System.out.println("TRANSACTION FAILED");
			// Return false statement
			return false;
		}
	}
	
	// Method for numberOfCheckingAccounts
	public int numberOfCheckingAccounts()
	{
		// Return the method numberOfCheckingAccounts from CheckingAccount class
		return CheckingAccount.numberOfCheckingAccounts;
	}
	
	// Method for adding interest
	public void addInterest()
	{
		// Integer variable to store the length
		int len = accounts.size();
		// For loop to iterate the accounts ArrayList
		for(int i = 0; i < len; i++)
		{
			// If statement to check if object in accounts is an instance of 'SavingAccount'
			if(accounts.get(i) instanceof SavingAccount)
			{
				// Interest variable created to store the interest, taking into account the balance and interest rate
				double interest = accounts.get(i).getBalance() * (savingsInterestRate / 100);
				// Deposit the new interest into the specified account
				accounts.get(i).deposit(interest);
			}
		}
	}
	
	// Method for re-setting checks on CheckingAccounts
	public void reset()
	{
		// Integer to store the lengths
		int len = accounts.size();
		// For loop to iterate the accounts ArrayList
		for(int i = 0; i < len; i++)
		{
			// Conditional if statement to check if object in account is an instance of 'CheckingAccount'
			if(accounts.get(i) instanceof CheckingAccount)
			{
				// Type cast object in accounts to a 'CheckingAccount', and then apply resetChecksUsed method
				((CheckingAccount) accounts.get(i)).resetChecksUsed();
			}
		}
	}
	

///////////////////////////////////// TESTING /////////////////////////////////////////////////////////
	
	// Add Account function
	public void addAccount(BankAccount account)
	{
		this.accounts.add(account);
	}
	
	// Output function
	public void output()
	{
		System.out.println("Bank: " + this.name);
		for(BankAccount account : accounts)
		System.out.print(account.toString());
	}
	
	// Main function
	public static void main(String args[]) 
	{
		// CREATE NEW BANK INSTANCE AND DISPLAY IT
		Bank bank1 = new Bank("Shakil Bank Of London", 10.0);
		bank1.output();
		// Bank bank2 = new Bank("Lahcen Bank Of London", 10.0);
		// bank2.output();
	
		// CREATE BANK ACCOUNTS (EITHER NORMAL BANK ACCOUNT OR SAVINGS/CHECKING ACCOUNT)
		BankAccount account1 = new BankAccount("001", 100.00);
		BankAccount account2 = new BankAccount("002", 100.00);
		SavingAccount account3 = new SavingAccount("003", 100.00);
		SavingAccount account4 = new SavingAccount("004", 100.00);
		CheckingAccount account5 = new CheckingAccount("005", 100.00);
		CheckingAccount account6 = new CheckingAccount("006", 100.00);
		
		// ADDING THE ACCOUNTS TO THE BANK
		bank1.addAccount(account1);
		bank1.addAccount(account2);
		bank1.addAccount(account3);
		bank1.addAccount(account4);
		bank1.addAccount(account5);
		bank1.addAccount(account6);
		
		// PRINT ALL THE ACCOUNTS
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// BANK TRANSFER TESTS
		// TRANSFER BETWEEN NORMAL BANK ACCOUNTS (NO PROBLEM)
		// �10 transferred, no extra charges incurred
//		System.out.println("Transfer between normal accounts");
//		bank1.transfer("002", "001", 10.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// TRANSFER BETWEEN BANK ACCOUNT AND SAVING ACCOUNT (NO PROBLEM)
		// �10 transferred, no extra charges incurred
//		System.out.println("Transfer between normal account and saving account");
//		bank1.transfer("001", "003", 10.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// TRANSFER BETWEEN BANK ACCOUNT AND CHECKING ACCOUNT (NO PROBLEM)
		// �10 transferred, �1 deducted from the checking account
//		System.out.println("Transfer Bank account and checking account");
//		bank1.transfer("001", "005", 10.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// TRANSFER BETWEEN SAVING ACCOUNT AND CHECKING ACCOUNT (NO PROBLEM)
		// �10 deposited, saving account charged �3, checking acccount charge �1
//		bank1.transfer("003", "005", 10.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// TRANSFER BETWEEN CHECKING ACCOUNT AND SAVING ACCOUNT (NO PROBLEM)
		// �10 deposited, checking account incurs �1 
//		bank1.transfer("005", "003", 10.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());


		// PRINT OUT THE BANK ACCOUNTS WHICH HAVE BEEN CREATED
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(account3.toString());
//		System.out.println(account4.toString());
//		System.out.println(account5.toString());
//		System.out.println(account6.toString());
		
		// TEST 1: ALL 'BANK' FUNCTIONS WORK WITH 'BANK' ACCOUNTS 
//		System.out.println(account1.toString());
//		System.out.println(account1.getBalance());
//		System.out.println(account1.getId());
//		account1.deposit(20.0);
//		System.out.println(account1.toString());
//		account1.withdraw(40.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		bank1.transfer("001", "002", 20.0);
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(bank1.numberOfCheckingAccounts());
//		bank1.addInterest();
//		System.out.println(account1.toString());
//		System.out.println(account2.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		bank1.reset();
//	    System.out.println(CheckingAccount.numberOfChecksUsed);
		
		
		// TEST 2: ALL CHECKINGACCOUNT FUNCTIONS WORK WITH CHECKING ACCOUNTS
		// checks for withdraw normal
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdraw(99.0);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.deposit(101);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		// checks for withdraw using cheque
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.resetChecksUsed();
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(48.0);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.resetChecksUsed();
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdraw(10.0);
//		account5.deposit(111);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
//		account5.withdrawUsingCheck(10.00);
//		System.out.println(account5.toString());
//		System.out.println(CheckingAccount.numberOfChecksUsed);
		
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		
//		account5.withdrawUsingCheck(10);
//		System.out.println(account5.toString());
//		
//		account5.resetChecksUsed();
//		
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
//		
//		account5.withdrawUsingCheck(10.0);
//		System.out.println(account5.toString());
		
		
	}
	
}
